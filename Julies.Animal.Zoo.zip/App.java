package Julies.zoo;

import java.util.ArrayList;
import java.util.HashMap;

public class App {
    private ArrayList<Animal> animalsList; private HashMap<String, Integer> speciesCount;
    public App() {
        animalsList = new ArrayList<>();
        speciesCount = new HashMap<>();
    }
// I applied the arraylist to the animals list and hashmap to the species count. It's all within arrays.
    public void processArrivingAnimals(String[] names, int[] ages, String[] species) {
        for (int i = 0; i < names.length; i++) {
            Animal animal = new Animal(names[i], ages[i], species[i]);
            animalsList.add(animal);
            speciesCount.put(species[i], speciesCount.getOrDefault(species[i], 0) + 1);

            System.out.println("New animal arrived: " + names[i] + " (Age: " + ages[i] + ", Species: " + species[i] + ")");
        }
    }

    public void generateReport() {
        System.out.println("\n- Animal Report -");
        for (Animal animal : animalsList) {
            System.out.println("Name: " + animal.getName() + ", Age: " + animal.getAge() + ", Species: " + animal.getSpecies());
        }

        System.out.println("\n- Species Count -");
        for (String species : speciesCount.keySet()) {
            System.out.println(species + ": " + speciesCount.get(species));
        }
    }

    public static void main(String[] args) {
        String[] hyenaNames = {"Larry", "Sharron"}; int[] hyenaAges = {7, 4}; String[] hyenaSpecies = {"Hyena", "Hyena"};

        String[] lionNames = {"Sarah"}; int[] lionAges = {6}; String[] lionSpecies = {"Lion"};

        String[] tigerNames = {"Coby", "Tara", "Trader", "Wally"};
        int[] tigerAges = {3, 4, 5, 2}; String[] tigerSpecies = {"Tiger", "Tiger", "Tiger", "Tiger"};

        String[] bearNames = {"Teddy", "Bella", "Cody"};
        int[] bearAges = {5, 6, 7};
        String[] bearSpecies = {"Bear", "Bear", "Bear"};
     //I organized it in this format because I wanted to see it organized together for better studying.
        App app = new App();
        System.out.println("- Two different Hyenas ");
        app.processArrivingAnimals(hyenaNames, hyenaAges, hyenaSpecies);
        System.out.println("\n- One Lion");
        app.processArrivingAnimals(lionNames, lionAges, lionSpecies);
        System.out.println("\n- Four different Tigers");
        app.processArrivingAnimals(tigerNames, tigerAges, tigerSpecies);
        System.out.println("\n- Three different Bears");
        app.processArrivingAnimals(bearNames, bearAges, bearSpecies);

        System.out.println("\n Julie's Zoo Animals Report");
        app.generateReport();
    }
}
// This is the end of my zoo, I need to study this better because I was confused. I provided a lot of system.out.println to run the code better.
// I'm not sure if this was right way to use it. It ran smoothly.



